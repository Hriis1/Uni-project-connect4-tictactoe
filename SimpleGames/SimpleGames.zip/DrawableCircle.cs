﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimpleGames
{
    class DrawableCircle
    {
        private System.Drawing.Point Position { get; set; }
        private int D { get; set; }

        public DrawableCircle(System.Drawing.Point pos, int d)
        {
            Position = pos;
            D = d;
        }
        public void Paint(System.Drawing.Graphics graphics, System.Drawing.Color color)
        {
            System.Drawing.Brush brush = new System.Drawing.SolidBrush(color);
            graphics.FillEllipse(brush,Position.X,Position.Y,D,D);
           
        }
    }
}
