﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace SimpleGames
{
    class DrawableLine
    {
        private System.Drawing.Point Pt1 { get; set; }
        private System.Drawing.Point Pt2 { get; set; }

        public DrawableLine(System.Drawing.Point pt1, System.Drawing.Point pt2)
        {
            Pt1 = pt1;
            Pt2 = pt2;
        }
        public void Paint(System.Drawing.Graphics graphics) 
        {
            System.Drawing.Pen p = new System.Drawing.Pen(System.Drawing.Color.Black);
            graphics.DrawLine(p, Pt1, Pt2);
        }

    }
}
